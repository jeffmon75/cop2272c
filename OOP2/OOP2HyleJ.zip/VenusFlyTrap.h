// Jeff Hyle
// COP2272C-02 Computer Programming I
// OOP2
// Time of last successful debugging: 10/30/19 7:30am

#pragma once

class VenusFlyTrap
{
public:
	double height;
	double mouthArea;

	VenusFlyTrap();

	VenusFlyTrap(double, double);

	void display();

	void trap();
};

